#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#define _CRT_SECURE_NO_WARNINGS
#include "stb_image.h"
#include "stb_image_write.h"
#include <iostream>

#define pixel_max(a) ((a) <= 255 ? (a) : 255)
#define pixel_min(a) ((a) >= 0 ? (a) : 0)

// Function to read an image in grayscale
unsigned char* readImage(const char* filename, int& width, int& height, int& channels) {
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 1); // Load as grayscale
    if (!image) {
        std::cerr << "Failed to load image: " << stbi_failure_reason() << std::endl;
        return nullptr;
    }
    std::cout << "Image loaded successfully!" << std::endl;
    std::cout << "Width: " << width << ", Height: " << height << ", Channels: " << channels << std::endl;
    return image;
}

// Function to write an image to a PNG file
bool writeImage(const char* filename, unsigned char* image, int width, int height) {
    if (!image) {
        std::cerr << "Image data is null before writing!" << std::endl;
        return false;
    }
    if (width <= 0 || height <= 0) {
        std::cerr << "Invalid image dimensions: width = " << width << ", height = " << height << std::endl;
        return false;
    }
    // For grayscale images, stride is the same as the width
    int stride = width;
    if (stbi_write_png(filename, width, height, 1, image, stride) == 0) {
        std::cerr << "Failed to write the image to file: " << filename << std::endl;
        return false;
    }
    std::cout << "Image written successfully to: " << filename << std::endl;
    return true;
}

int main() {
    // Input and output file paths
    const char* inputFilename = "input_image3.png";
    const char* outputFilename1 = "output_image1.png";
    const char* outputFilename2 = "output_image2.png";

    // Image data variables
    int width, height, channels; // channels = 1 (grayscale)
    unsigned int number_of_pixels;

    // Read the input image
    unsigned char* image = readImage(inputFilename, width, height, channels);
    if (!image) 
        return -1; // Exit if the image failed to load

    
    // Allocate memory for the output image
    unsigned char* outputImage = new unsigned char[width * height];
    if (!outputImage) {
        std::cerr << "Failed to allocate memory for output image!" << std::endl;
        stbi_image_free(image);
        return -1;
    }

    // image is 1d array 
    // with length = width * height
    // pixels can be used as image[i] 
    // pixels can be updated as image[i] = 100, etc.
    // a pixel is defined as unsigned char
    // so a pixel can be 255 at max, and 0 at min.

    /* -------------------------------------------------------- QUESTION-1 -------------------------------------------------------- */
    
    /* Q-1 Inverse the colors of image. 
    Inverse -> pixel_color = 255 - pixel_color */

    number_of_pixels = width * height;
    
    __asm {
        mov ecx, number_of_pixels // Piksel say�s�n� ECX'e y�kle
        xor esi, esi // ESI'yi s�f�rl�yoruz, piksel indeksini tutacak
        mov ebx, image // G�r�nt� ba�lang�� adresini EBX'e y�kle
        mov edi, outputImage// ��kt� g�r�nt�s�n�n ba�lang�� adresini EDI'ye y�kle

        l1:
            mov al, [ebx + esi] // Pikseli AL register'�na y�kle (8-bit okuma)
            neg al // Piksel de�erini tersine �evir(255 - piksel de�eri)
            add al,255
            mov[edi + esi], al // Sonu�lar� ��kt� g�r�nt�s�ne yaz

            inc esi // Piksel indeksini artt�r
            loop l1// ECX'e kadar d�ng�y� tekrarla
    }


    // Write the modified image as output_image1.png
    if (!writeImage(outputFilename1, outputImage, width, height)) {
        stbi_image_free(image);
        return -1;
    }
    stbi_image_free(outputImage); // Clear the outputImage.

    /* -------------------------------------------------------- QUESTION-2 -------------------------------------------------------- */
    /* Histogram Equalization */

    outputImage = new unsigned char[width * height];
    if (!outputImage) {
        std::cerr << "Failed to allocate memory for output image!" << std::endl;
        stbi_image_free(image);
        return -1;
    }

    unsigned int* hist = (unsigned int*)malloc(sizeof(unsigned int) * 256);
    unsigned int* cdf = (unsigned int*)malloc(sizeof(unsigned int) * 256);

    // Check if memory allocation succeeded
    if (hist == NULL) {
        std::cerr << "Memory allocation for hist failed!" << std::endl;
        return -1;
    }
    std::cout << "hist olustu!" << std::endl;
    if (cdf == NULL) {
        std::cerr << "Memory allocation for cdf failed!" << std::endl;
        free(hist);
        return -1;
    }
    std::cout << "cdf olustu!" << std::endl;
    // Both hist and cdf are initialized as zeros.
    for (int i = 0; i < 256; i++) {
        hist[i] = 0;
        cdf[i] = 0;
    }

    // You can define new variables here... As a hint some variables are already defined.
    unsigned int min_cdf, range;
    number_of_pixels = width * height;

    // Q-2 (a) - Compute the histogram of the input image.
    // hist[image[i]]++;
    __asm {
        // Your assembly code here...
        mov ecx, number_of_pixels
        XOR esi,esi
        // burada image bayt bayt ilerliyor
          // edi=hist in 0.de�erinin adresi 4er 4 er artacak
        
      l2:
        //xor eax,eax
        mov ebx, image
        mov edi, hist
            add ebx,esi
            mov al,[ebx] // eax=image[i]
            mov dl,4
            mul dl
            movzx eax, ax
            add edi,eax
            inc dword ptr [edi]
            inc esi
            loop l2
    }
    for (int i = 0; i < 256; i++) {
        std::cout << hist[i] << " ";
    }
    std::cout << std::endl;
    
    
    std::cout << "histogram yazdirildi" << std::endl;

    /* Q - 2 (b)-Compute the Cumulative Distribution Function cdf
                    and save it to cdf array which is defined above. */

    // CDF Calculation (cdf[i] = cdf[i-1] + hist[i])
    
    __asm {
       // �lk eleman i�in cdf[0] = hist[0]
        mov ebx, cdf  // ebx = cdf ba�lang�� adresi
        mov edi, hist// edi = hist ba�lang�� adresi
        mov eax, [edi] // eax = hist[0]
        mov[ebx], eax // cdf[0] = hist[0]

        
        mov ecx, 255 // D�ng� sayac�(cdf[1] - cdf[255])
        mov esi, 4 // Her eleman aras�ndaki fark 4 byte
        add ebx, esi // ebx = cdf[1]'in adresi
        add edi, esi // edi = hist[1]'in adresi

        l3:
        mov eax, [ebx - 4]// eax = cdf[i - 1]
            add eax, [edi] // eax = cdf[i - 1] + hist[i]
            mov[ebx], eax // cdf[i] = eax
            add ebx, esi // ebx = cdf[i + 1]'in adresi
            add edi, esi // edi = hist[i + 1]'in adresi
            loop l3 // D�ng�n�n ba��na d�n
    }
    for (int i = 0; i < 256; i++) {
        std::cout << cdf[i] << " ";
    }
    std::cout << std::endl;

    
    /* Q-2 (c) - Normalize the Cumulative Distribution Funtion 
                    that you have just calculated on the same cdf array. */

    // Normalized cdf[i] = ((cdf[i] - min_cdf) * 255) / range
    // range = (number_of_pixels - min_cdf)
    
    __asm {
        // Your assembly code here...
        // �nce min_cdf yi bulmak gerekebilir
        // buldu�umuzu varsayarark i�lemleri yap�yorum
        // cdf dizisindeki 0 dan b�y�k ilk de�er
        xor esi, esi
        mov ebx, cdf
        mov ecx, 255
        while_:
        cmp esi, ecx
            jae son
            add ebx, esi // cdf[i]
            cmp[ebx], 0
            jae son
            add esi, 4
            jmp while_
            son :
        mov eax, [ebx]
            mov min_cdf, eax
    }
    std::cout << min_cdf ;
    std::cout << std::endl;
    // min_cdf=16 cdf deki her de�er zaten minden b�y�k
    __asm{
 
        mov ecx,number_of_pixels
        sub ecx,min_cdf
        mov range,ecx

        xor esi,esi
        mov ecx ,256
       
        l4:
            mov ebx, cdf
            add ebx,esi // cdf[i] adresi
            mov eax,[ebx] // eax te de�er var 
            sub eax,min_cdf
            mov edx,255
            mul edx
            mov edi,range
            div edi
            mov [ebx],eax
            add esi,4
            loop l4 
    }

    for (int i = 0; i < 256; i++) {
        std::cout << cdf[i] << " ";
    }
    std::cout << std::endl;

    
    
    /* Q-2 (d) - Apply the histogram equalization on the image.
                    Write the new pixels to outputImage. */
	// Here you only need to get a pixel from image, say the value of pixel is 107
	// Then you need to find the corresponding cdf value for that pixel
	// The output for the pixel 107 will be cdf[107]
	// Do this for all the pixels in input image and write on output image.
    // output[i]=cdf[image[i]];
    __asm {
        // Your assembly code here...
        mov ecx,number_of_pixels
        xor edx,edx
        l5:
            mov ebx,image //adres al�yorum adres 32bitlik
            //movzx ebx,bl
            add ebx,edx // image[i] address
            mov esi,cdf
            mov bl,[ebx]
            movzx ebx,bl
            shl ebx, 2
            add esi,ebx // cdf[image[i]] address
            mov edi,outputImage
            add edi,edx // output[i] address
            mov eax,[esi]
            mov [edi],al // output a de�eri y�kleme
            inc edx
            loop l5
    }
    
    
    for (int i = 0; i < 256; i++) {
        std::cout << outputImage[i] << " ";
    }
    std::cout << std::endl;
    
    
    // Write the modified image
    if (!writeImage(outputFilename2, outputImage, width, height)) {
        stbi_image_free(image); 
        return -1;
    }

    // Free the image memory
    stbi_image_free(image);
    stbi_image_free(outputImage);

    return 0;
}
